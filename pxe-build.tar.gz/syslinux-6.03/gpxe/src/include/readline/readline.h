#ifndef _READLINE_H
#define _READLINE_H

/** @file
 *
 * Minmal readline
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern char * __malloc readline ( const char *prompt );

#endif /* _READLINE_H */
