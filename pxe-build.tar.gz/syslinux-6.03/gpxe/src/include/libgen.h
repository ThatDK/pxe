#ifndef _LIBGEN_H
#define _LIBGEN_H

FILE_LICENCE ( GPL2_OR_LATER );

extern char * basename ( char *path );
extern char * dirname ( char *path );

#endif /* _LIBGEN_H */
