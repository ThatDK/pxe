#ifndef _BITS_NAP_H
#define _BITS_NAP_H

/** @file
 *
 * x86_64-specific CPU sleeping API implementations
 *
 */

#include <gpxe/efi/efix86_nap.h>

#endif /* _BITS_MAP_H */
