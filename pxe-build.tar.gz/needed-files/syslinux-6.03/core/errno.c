#include <klibc/compiler.h>
#include <errno.h>

__export int errno;
