#ifndef __LWIP_ARCH_PERF_H__
#define __LWIP_ARCH_PERF_H__

#define PERF_START
#define PERF_STOP(x)

#endif /* __LWIP_ARCH_PERF_H__ */
