#define VERSION 6.03
#define VERSION_STR "6.03"
#define VERSION_MAJOR 6
#define VERSION_MINOR 3
#define YEAR 2014
#define YEAR_STR "2014"
