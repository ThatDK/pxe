#ifndef CMDLINE_H
#define CMDLINE_H

/* Command line external functions */

void cmdl_start();

#endif
