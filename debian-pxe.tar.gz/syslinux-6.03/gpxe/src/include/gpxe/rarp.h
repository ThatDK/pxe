#ifndef _GPXE_RARP_H
#define _GPXE_RARP_H

/** @file
 *
 * Reverse Address Resolution Protocol
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

struct net_protocol;

extern struct net_protocol rarp_protocol;

#endif /* _GPXE_RARP_H */
