#ifndef _USR_ROUTE_H
#define _USR_ROUTE_H

/** @file
 *
 * Routing table management
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern void route ( void );

#endif /* _USR_ROUTE_H */
